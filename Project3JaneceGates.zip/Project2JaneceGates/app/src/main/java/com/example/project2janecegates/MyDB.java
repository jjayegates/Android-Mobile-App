package com.example.project2janecegates;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

public class MyDB extends SQLiteOpenHelper {



    public MyDB(Context context){
        super(context , "app_db", null, 1);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        String createTable1 = " CREATE TABLE IF NOT EXISTS credentials (username TEXT, password TEXT)";
        String createTable2 = " CREATE TABLE IF NOT EXISTS inventory (name TEXT,  description TEXT, qty INTEGER)";

        db.execSQL(createTable1);
        db.execSQL(createTable2);

    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {

    }
}