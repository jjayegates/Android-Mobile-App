package com.example.project2janecegates;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import android.content.ContentValues;
import android.content.Context;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.os.Bundle;
import android.view.View;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.SearchView;
import android.widget.TableRow;
import android.widget.TextView;
import android.Manifest;

public class MainActivity extends AppCompatActivity {
    MyDB1 appDB;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        appDB = new MyDB1(this);
    }


    public void AttemptLogin(View v){
        // make sure the contents of nameText are not null
        View vParent = (View) v.getParent() ;
        EditText usr = (EditText) vParent.findViewById(R.id.username) ;
        EditText pwd = (EditText) vParent.findViewById(R.id.password) ;
        String userName =  usr.getText().toString();
        String passWord =  pwd.getText().toString().replace(" ", "");

        boolean userNameMatch = false;
        boolean passWordMatch = false;

        // database code to determine matches
        SQLiteDatabase db_r = appDB.getReadableDatabase();
        Cursor cursor = db_r.query("credentials", null, String.format("username = ?"), new String[]{userName}, null, null, null);
        while(cursor.moveToNext()){
            userNameMatch = true ;
            int uNameInd = cursor.getColumnIndex("username");
            int passInd = cursor.getColumnIndex("password");

            String uname = cursor.getString(uNameInd) ;
            String pass = cursor.getString(passInd);

            if (pass.equals(passWord)){
                passWordMatch = true;
            }
        }

        // Scenario 1
        if (userNameMatch && passWordMatch){
            switchToDefaultDatabaseView();

            if (ContextCompat.checkSelfPermission(this, Manifest.permission.SEND_SMS ) != PackageManager.PERMISSION_GRANTED) {
                ActivityCompat.requestPermissions(this, new String[] {Manifest.permission.SEND_SMS}, 1);
            }
        }

        // Scenario 2
        if (userNameMatch && !passWordMatch){
            TextView resMsg = (TextView) vParent.findViewById(R.id.LoginResultMessage) ;
            resMsg.setText("Incorrect Password.  Please Try Again.");

            if (ContextCompat.checkSelfPermission(this, Manifest.permission.SEND_SMS ) != PackageManager.PERMISSION_GRANTED) {
                ActivityCompat.requestPermissions(this, new String[] {Manifest.permission.SEND_SMS}, 0);
            }
        }

        // Scenario 3
        if (!userNameMatch){
            TextView resMsg = (TextView) vParent.findViewById(R.id.LoginResultMessage) ;
            TextView regBut = (TextView) vParent.findViewById(R.id.RegisterButton) ;
            regBut.setVisibility(View.VISIBLE);
            resMsg.setText("Credentials do not exist.  Would you like to register a new account?");
        }

    }


    public void goToAddPage(View v){
        setContentView(R.layout.content_add_item_page);
    }

    public void addRow(String itemName, String itemDesc, int itemQty) {
        LinearLayout rowContainer = (LinearLayout) findViewById(R.id.rowHolder);
        //LinearLayout rowContainer1 = (LinearLayout) findViewById(R.id.rowHolder) ;

        TableRow.LayoutParams paramsR = new TableRow.LayoutParams(
                0, //width
                TableRow.LayoutParams.MATCH_PARENT, // height
                1 // weight
        );
        TableRow.LayoutParams paramsR_desc = new TableRow.LayoutParams(
                0, //width
                TableRow.LayoutParams.MATCH_PARENT, // height
                2 // weight
        );
        TableRow.LayoutParams paramsL = new TableRow.LayoutParams(
                1000, //TableRow.LayoutParams.MATCH_PARENT, //width
                TableRow.LayoutParams.MATCH_PARENT // height
        );

        TableRow row = new TableRow(this);
        row.setLayoutParams(paramsL);
        CheckBox cb = new CheckBox(this);
        cb.setLayoutParams(paramsR);
        EditText nameField = new EditText(this);
        nameField.setText(itemName);
        nameField.setLayoutParams(paramsR);
        EditText descField = new EditText(this);
        descField.setText(itemDesc);
        descField.setLayoutParams(paramsR_desc);
        EditText qtyField = new EditText(this);
        qtyField.setText(""+itemQty);
        qtyField.setLayoutParams(paramsR);
        row.addView(cb);
        row.addView(nameField);
        row.addView(descField);
        row.addView(qtyField);
        rowContainer.addView(row);
    }

    public void AttemptRegister(View v){
        View vParent = (View) v.getParent().getParent() ;
        EditText usr = (EditText) vParent.findViewById(R.id.username) ;
        EditText pwd = (EditText) vParent.findViewById(R.id.password) ;
        String userName =  usr.getText().toString();
        String passWord =  pwd.getText().toString();

        SQLiteDatabase db = appDB.getWritableDatabase();
        ContentValues vals = new ContentValues() ;

        vals.put("username", userName);
        vals.put("password", passWord);
        long newRowId = db.insert("credentials", null, vals);


        switchToDefaultDatabaseView();
    }

    public void addItemToDB(View v){
        SQLiteDatabase db = appDB.getWritableDatabase();
        ContentValues vals = new ContentValues() ;

        EditText name = (EditText) findViewById(R.id.itemNameEdit) ;
        EditText desc = (EditText) findViewById(R.id.itemDescEdit) ;
        EditText qty = (EditText) findViewById(R.id.itemQtyEdit) ;



        vals.put("name", name.getText().toString());
        vals.put("description", desc.getText().toString());
        vals.put("qty", Integer.parseInt(qty.getText().toString()));
        long newRowId = db.insert("inventory", null, vals);


        // just put this in a function and then call the function whenever switching to this page...
        switchToDefaultDatabaseView();


        // once the above is finished, just need to
            //1  make sure delete works
            //2  make sure search works
            //3 do the paper
    }



    public void clearRows(){
        LinearLayout rowContainer = (LinearLayout) findViewById(R.id.rowHolder);
        rowContainer.removeAllViews();
    }

    public void deleteSelected(View v){
        LinearLayout rowContainer = (LinearLayout) findViewById(R.id.rowHolder);
        int numRows = rowContainer.getChildCount();
        for (int i = 0; i < numRows; i++){
            TableRow row = (TableRow) rowContainer.getChildAt(i);
            CheckBox cb = (CheckBox) row.getChildAt(0);
            if (cb.isChecked() ){
                EditText nameEdit = (EditText) row.getChildAt(1);
                String nameMatch = nameEdit.getText().toString();

                // this means that the checkbox is selected so we need ot delete this row
                SQLiteDatabase db_w = appDB.getWritableDatabase();
                db_w.delete(  "inventory", "name=?", new String[]{nameMatch}) ;
            }
        }

        switchToDefaultDatabaseView();

    }

    public void switchToDefaultDatabaseView(){
        setContentView(R.layout.activity_database_information);
        SearchView searchBar = (SearchView) findViewById(R.id.searchBar) ;
        searchBar.setOnQueryTextListener(new SearchView.OnQueryTextListener() {

            @Override
            public boolean onQueryTextSubmit(String query) {
                return false;
            }

            @Override
            public boolean onQueryTextChange(String newText) {
                clearRows();
                DisplayDatabaseItems("name", newText) ;
                return true;
            }
        });
        DisplayDatabaseItems(null, null) ;
    }

    public void DisplayDatabaseItems(String column, String value){
        String arg1 = null;
        String[] arg2 = null;
        if (column != null) {
            arg1 = column + " = ?";
            arg2 = new String[]{value};
        }
        SQLiteDatabase db_r = appDB.getReadableDatabase();
        Cursor cursor = db_r.query("inventory", null, arg1, arg2, null, null, null);
        while(cursor.moveToNext()){
            int uNameInd = cursor.getColumnIndex("name");
            int descInd = cursor.getColumnIndex("description");
            int qtyInd = cursor.getColumnIndex("qty");

            String itemName = cursor.getString(uNameInd) ;
            String itemDesc = cursor.getString(descInd) ;
            int itemQty = cursor.getInt(qtyInd);

            addRow(itemName, itemDesc, itemQty);
        }
    }
}


class MyDB1 extends SQLiteOpenHelper {



    public MyDB1(Context context){
        super(context , "app_db", null, 1);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        String createTable1 = " CREATE TABLE IF NOT EXISTS credentials (username TEXT, password TEXT)";
        String createTable2 = " CREATE TABLE IF NOT EXISTS inventory (name TEXT,  description TEXT, qty INTEGER)";

        db.execSQL(createTable1);
        db.execSQL(createTable2);

    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {

    }
}